import pygame
import random
import math

class Ball:
    def __init__(self, x, y, width, height, screen_width, screen_height):
        self.original_x = x
        self.original_y = y
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.screen_width = screen_width
        self.screen_height = screen_height

        # start speeds (integers)
        self.velocity_x = random.choice([-5, 5])
        self.velocity_y = random.choice([-3, 3])

    def move(self):
        self.x += self.velocity_x
        self.y += self.velocity_y

        # bounce top/bottom
        if self.y <= 0:
            self.y = 0
            self.velocity_y *= -1
        elif self.y + self.height >= self.screen_height:
            self.y = self.screen_height - self.height
            self.velocity_y *= -1

    def check_collision(self, player, ai):
        # If colliding with player/ai, flip X velocity and push ball outside paddle to avoid sticking
        if self.rect().colliderect(player.rect()):
            # push to the right of player paddle
            self.x = player.x + player.width
            self._on_paddle_hit(player)
        elif self.rect().colliderect(ai.rect()):
            # push to the left of ai paddle
            self.x = ai.x - self.width
            self._on_paddle_hit(ai)

    def _on_paddle_hit(self, paddle):
        # Reverse X velocity
        # Increase horizontal speed by 1 (preserve sign) to make rally escalate slightly
        sign = 1 if self.velocity_x >= 0 else -1
        new_speed = abs(self.velocity_x) + 1
        self.velocity_x = -sign * new_speed

        # Optional: change Y velocity slightly depending on where it hit the paddle
        # compute offset from paddle center (-1..1)
        paddle_center = paddle.y + paddle.height / 2
        ball_center = self.y + self.height / 2
        offset = (ball_center - paddle_center) / (paddle.height / 2)  # -1..1 approx
        # map offset to a small change in Y velocity
        self.velocity_y += int(offset * 3)
        # clamp vertical speed to reasonable bounds
        max_vy = 8
        self.velocity_y = max(-max_vy, min(max_vy, self.velocity_y))

    def reset(self):
        self.x = self.original_x
        self.y = self.original_y
        # choose fresh directions on reset to avoid deterministic flips
        self.velocity_x = random.choice([-5, 5])
        self.velocity_y = random.choice([-3, 3])

    def rect(self):
        return pygame.Rect(int(self.x), int(self.y), self.width, self.height)
