import pygame

class Paddle:
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.speed = 7

    def move(self, dy, screen_height):
        self.y += dy
        # clamp within screen
        self.y = max(0, min(self.y, screen_height - self.height))

    def rect(self):
        return pygame.Rect(int(self.x), int(self.y), self.width, self.height)

    def auto_track(self, ball, screen_height):
        # track ball center vs paddle center for smoother response
        paddle_center = self.y + self.height / 2
        ball_center = ball.y + ball.height / 2

        if ball_center < paddle_center - 5:
            self.move(-self.speed, screen_height)
        elif ball_center > paddle_center + 5:
            self.move(self.speed, screen_height)
